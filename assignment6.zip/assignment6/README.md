# assignment6

本精简包只有 3 个文件：

- `assignment6.ipynb`：完整代码、运行输出和三道书面题答案。作业所需库源码已内置，不需要另下载代码文件夹。
- `requirements.txt`：Python 依赖。
- `README.md`：本说明。

## 运行

使用 Python 3.11，安装依赖：

```bash
python -m pip install -r requirements.txt
python -m jupyter notebook
```

打开 notebook，选择 Python 3.11 内核，再点击 Restart Kernel and Run All Cells。
第一个代码单元会把内置源码写入临时目录，供本次运行导入；关闭会话后清理。
该单元较长，默认折叠，可以展开查看全部源码。

单独下载的 `.ipynb` 与压缩包中的 notebook 完全相同；安装依赖后也能独立运行。
若没有依赖清单，可以使用 notebook 开头提供的 `%pip install` 命令。

## 上传 GitHub

解压后将这 3 个文件上传到你的仓库即可。GitHub 可以预览 notebook 中的结果。
此版本将代码库内置于 notebook；如果老师明确要求原始 `fixedincomelib` 文件目录结构，请使用先前的完整版。

## 验证

精简版在空目录、独立 Python 3.11 进程中逐单元执行，19 个代码单元全部成功。
原有定价断言和新增 FX 检查均通过。验证使用 IPython 进程执行，未使用 Jupyter 内核通信。
